try:
    pass
finally:
    # pylint: disable=W0201
    pass
