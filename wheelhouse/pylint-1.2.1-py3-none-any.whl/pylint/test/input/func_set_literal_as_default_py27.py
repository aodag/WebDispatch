"""docstring"""

__revision__ = ''

def function1(value={1}):
    """set is mutable and dangerous."""
    print(value)
