'''
Regression test for
https://bitbucket.org/logilab/pylint/issue/128/attributeerror-when-parsing
'''

__revision__ = 1

def do_nothing():
    """ empty """
    with open("") as ctx.obj:
        context.do()
        context = None
