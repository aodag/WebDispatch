# pylint: errors-only
"""errors-only is not usable as an inline option"""
__revision__ = None

CONST = "This is not a pylint: inline option."
