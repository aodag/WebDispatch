# pylint: disable=C0103
"""test built-in redefinition
"""
__revision__ = 0

def function():
    """yo"""
    type = 1
    print(type)

map = {}
