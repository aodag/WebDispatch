
name = 'a'
_bla = 2
other = 'o'
class Aaa: pass

def func(): print 'yo'

