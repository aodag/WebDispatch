print('yo')
