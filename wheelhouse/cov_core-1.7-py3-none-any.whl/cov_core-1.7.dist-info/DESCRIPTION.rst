cov-core
========

This is a lib package for use by pytest-cov, nose-cov and nose2-cov.  Unless your developing a
coverage plugin for a test framework then you probably want one of those.

